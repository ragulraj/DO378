export interface NewsItem {
    id: string;
    title: string;
    timestamp: string;
}
