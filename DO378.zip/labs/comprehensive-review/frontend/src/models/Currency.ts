interface Currency {
    value: string;
    date: string;
    sign?: string;
    name?: string;
}

export default Currency;
