#!/bin/sh

gnome-terminal --tab -t Frontend -- ~/DO378/labs/comprehensive-review/frontend/start.sh
gnome-terminal --tab -t News -- ~/DO378/labs/comprehensive-review/news/start.sh
gnome-terminal --tab -t History -- ~/DO378/labs/comprehensive-review/history/start.sh
gnome-terminal --tab -t Keycloak -- ~/DO378/labs/comprehensive-review/start-keycloak.sh
