package com.redhat.exchange.dto;

public class Exchange {
    public String sign;
    public String name;
    public String value;
    public String date;
}
