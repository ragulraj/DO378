package com.redhat.exchange.dto;

public class ExchangeRequest {
    public String source;
    public String target;
}
