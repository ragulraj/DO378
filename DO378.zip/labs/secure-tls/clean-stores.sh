#!/bin/bash

cd ~/DO378/labs/secure-tls/

rm -f solver/solver.*
rm -f adder/adder.*
rm -f multiplier/multiplier.*

echo "All certs, trust, and  key stores removed."
