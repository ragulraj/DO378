export interface Schedule {
    id: number;
    venueId: number;
    startTime: string;
    date: Date;
}
