insert into schedule (id,venue_id,date) values (NEXT VALUE FOR HIBERNATE_SEQUENCE, 1,'2020-9-04');
insert into schedule (id,venue_id,date) values (NEXT VALUE FOR HIBERNATE_SEQUENCE, 1,'2020-9-05');
insert into schedule (id,venue_id,date) values (NEXT VALUE FOR HIBERNATE_SEQUENCE, 2,'2020-9-04');
insert into schedule (id,venue_id,date) values (101, 101,'2020-9-01');
