package org.acme.conference.vote;

import io.quarkus.test.junit.NativeImageTest;

@NativeImageTest
public class NativeVoteResourceIT extends HelloResourceTest {

    // Execute the same tests but in native mode.
}
