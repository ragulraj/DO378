insert into Expense (id, name, paymentmethod, amount)
 values (nextval('hibernate_sequence'), 'Groceries', '0','150.50');
insert into Expense (id, name, paymentmethod, amount)
 values (nextval('hibernate_sequence'), 'Civilization VI', '1','25.00');
