package org.acme.rest.json;

import org.junit.jupiter.api.Test;

public class ExpensesCreationTest {
   
    @Test
    public void testCreateExpense() {

    }

}