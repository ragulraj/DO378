package org.acme.conference.speaker.idgenerator;

public interface IdGenerator {
    public String generate();
}
